import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { baseUrlAuth } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private tokenExpirationTimer: any;

  constructor(private http: HttpClient) { }

  generateToken(credentials: any) {
    console.log(credentials);
    
    return this.http.post(`${baseUrlAuth}authenticate`,credentials)
  }
  autoLogout() {

   

    this.tokenExpirationTimer = setTimeout(() => {

     

      alert("Your Seession got expired");

      this.logout();

    }, 1800000);

  }

  loginUser(token:string){
    localStorage.setItem("token",token);
    console.log("user log in");
    this.autoLogout();
    this.isLoggedIn();
    return true;
  }

  logout() {
    localStorage.removeItem('token');
    console.log("U--ser logout");

    location.reload();
    return true;
  }

  getToken() {
    return localStorage.getItem("token");
  }

  isLoggedIn() {
    let token = localStorage.getItem("token");
    if(token===undefined || token===''||token==null) {
      console.log("Logged in");
      
      return false;
    }
    else{
      console.log("not logged");
      return true;
    }
  }


}
