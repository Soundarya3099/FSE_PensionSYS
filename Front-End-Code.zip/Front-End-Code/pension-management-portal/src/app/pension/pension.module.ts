import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewPensionComponent } from './view-pension/view-pension.component';
// import { ListPensionerDetailComponent } from '../pensioner/list-pensioner-detail/list-pensioner-detail.component';
// import { SearchPensionerComponent } from '../pensioner/search-pensioner/search-pensioner.component';
// import { MAT_SNACK_BAR_DEFAULT_OPTIONS } from '@angular/material/snack-bar';



@NgModule({
  declarations: [
    // ListPensionerDetailComponent,
    ViewPensionComponent,
    // SearchPensionerComponent
  ],
  imports: [
    CommonModule
  ],
//   exports: [
//     SearchPensionerComponent
//   ],
//   providers:[
//  {provide: MAT_SNACK_BAR_DEFAULT_OPTIONS,useValue: {duration: 2500} }
//   ]
})
export class PensionModule { }
