package com.pms.auth;

public class Constants {

	public static final String DEBUG = "DEBUG";
	public static final String INFO = "INFO";
	public static final String ERROR = "ERROR";
	public static final String VALIDITY = "1800";
	public static final String USER_DISABLED = "USER_DISABLED";
	public static final String INVALID_CREDENTIALS = "INVALID_CREDENTIALS";
	
}
