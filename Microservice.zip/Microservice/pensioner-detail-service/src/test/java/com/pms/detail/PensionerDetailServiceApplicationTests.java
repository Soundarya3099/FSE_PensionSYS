package com.pms.detail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PensionerDetailServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
