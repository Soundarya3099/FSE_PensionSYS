package com.pms.process.exception;

public class PensionerDetailException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PensionerDetailException(String message)
	{
		super(message);
	}

}
