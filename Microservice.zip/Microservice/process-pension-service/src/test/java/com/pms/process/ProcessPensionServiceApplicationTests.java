package com.pms.process;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcessPensionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
